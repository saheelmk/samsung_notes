import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:samsung_note/widgets/alertContainer.dart';

class ManageFolderScreen extends HookWidget {
  final Color backgroundCOlor;
  final Color boxColor;
  final Color textColor;

  ManageFolderScreen({
    super.key,
    required this.backgroundCOlor,
    required this.boxColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final Widget divider = Container(
      margin: const EdgeInsets.only(left: 10, right: 10),
      height: 1,
      color: Colors.grey[350],
    );

    return SizedBox(
      height: MediaQuery.of(context).size.height,
      child: Scaffold(
        backgroundColor: backgroundCOlor,
        appBar: AppBar(
          toolbarHeight: 70,
          backgroundColor: backgroundCOlor,
          title: const Text("Manage folders"),
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back_ios_new),
          ),
          titleSpacing: 0.0,
        ),
        body: ListView(
          children: [
            Container(
              decoration: BoxDecoration(
                color: boxColor,
                borderRadius: const BorderRadius.all(
                  Radius.circular(20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.only(left: 20),
                    width: MediaQuery.of(context).size.width,
                    child: TextButton.icon(
                      onPressed: () {},
                      label: Text(
                        "Folders",
                        style: TextStyle(fontSize: 16, color: textColor),
                      ),
                      icon: Icon(
                        Icons.folder_outlined,
                        color: textColor,
                      ),
                      style: TextButton.styleFrom(
                        alignment: Alignment.centerLeft,
                      ),
                    ),
                  ),
                  divider,
                  Container(
                    padding: const EdgeInsets.only(left: 20),
                    width: MediaQuery.of(context).size.width,
                    child: TextButton.icon(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext ctx) => AlertDialog(
                            backgroundColor: Colors.white,
                            title: const Text(
                              "Create folder",
                              style: TextStyle(fontSize: 18),
                            ),
                            content: Alertcontainer(),
                          ),
                        );
                      },
                      label: Text(
                        "Create folder",
                        style: TextStyle(fontSize: 16, color: textColor),
                      ),
                      icon: const Icon(
                        Icons.add,
                        color: Colors.green,
                      ),
                      style: TextButton.styleFrom(
                        alignment: Alignment.centerLeft,
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}















// import 'package:flutter/material.dart';
// import 'package:flutter_hooks/flutter_hooks.dart';
// import 'alertContainer.dart';

// class ManageFolderScreen extends HookWidget {
//   final Color backgroundColor;
//   final Color boxColor;
//   final Color textColor;

//   ManageFolderScreen({
//     super.key,
//     required this.backgroundColor,
//     required this.boxColor,
//     required this.textColor,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final folders = useState<List<Map<String, dynamic>>>([]);

//     // Divider Widget
//     final Widget divider = Container(
//       margin: const EdgeInsets.only(left: 10, right: 10),
//       height: 1,
//       color: Colors.grey[350],
//     );

//     // Add a folder to the list
//     void addFolder(String name, Color color) {
//       folders.value = [
//         ...folders.value,
//         {"name": name, "color": color}
//       ];
//     }

//     return Scaffold(
//       backgroundColor: backgroundColor,
//       appBar: AppBar(
//         toolbarHeight: 70,
//         backgroundColor: backgroundColor,
//         title: const Text("Manage folders"),
//         leading: IconButton(
//           onPressed: () {
//             Navigator.pop(context);
//           },
//           icon: const Icon(Icons.arrow_back_ios_new),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () {},
//             child: const Text(
//               "Edit",
//               style: TextStyle(color: Colors.blue, fontSize: 16),
//             ),
//           ),
//         ],
//       ),
//       body: ListView(
//         children: [
//           Container(
//             decoration: BoxDecoration(
//               color: boxColor,
//               borderRadius: const BorderRadius.all(Radius.circular(20)),
//             ),
//             child: Column(
//               children: [
//                 // "Folders" Header
//                 ListTile(
//                   leading: const Icon(Icons.folder_outlined),
//                   title: const Text("Folders"),
//                   trailing: Text(
//                     "${folders.value.length}",
//                     style: TextStyle(color: textColor),
//                   ),
//                 ),
//                 divider,
//                 // Display Created Folders
//                 ...folders.value.map((folder) {
//                   return ListTile(
//                     leading: Icon(Icons.folder, color: folder['color']),
//                     title: Text(folder['name']),
//                   );
//                 }).toList(),
//                 divider,
//                 // Create Folder Button
//                 ListTile(
//                   leading: const Icon(Icons.add, color: Colors.green),
//                   title: TextButton(
//                     onPressed: () {
//                       showDialog(
//                         context: context,
//                         builder: (ctx) => AlertDialog(
//                           backgroundColor: Colors.white,
//                           title: const Text("Create folder"),
//                           content: Alertcontainer(
//                             onAdd: (folderName, folderColor) {
//                               addFolder(folderName, folderColor);
//                             },
//                           ),
//                         ),
//                       );
//                     },
//                     child: const Text(
//                       "Create folder",
//                       style: TextStyle(fontSize: 16),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
