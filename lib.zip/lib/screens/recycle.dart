import 'package:flutter/material.dart';
import 'package:samsung_note/themes/extension/theme.dart';
import 'package:samsung_note/screens/one_ui_nested_scroll.dart';
import 'package:samsung_note/widgets/appDrawers/drawer.dart';
import 'package:samsung_note/widgets/note_model.dart';

class RecycleWidget extends StatelessWidget {
  final List<NoteModel> recycleBinNotes;

  const RecycleWidget({required this.recycleBinNotes, super.key});

  @override
  Widget build(BuildContext context) {
    final customColors = Theme.of(context).extension<ThemeWidget>()!;

    return Scaffold(
      drawer: AppDrawer(
        recycleBinNotes: [],
        settingsBackgroundColor: customColors.primaryColor,
        drawerColor: customColors.randomColor,
        textColor: customColors.secondaryColor,
        folderColor: customColors.buttonColor,
      ),
      body: OneUiNested(
        onLongPressed: () {},
        expandedHeight: 300,
        toolbarHeight: 30,
        expandedWidget: Text(
          "Recycle bin",
          style: TextStyle(fontSize: 30, color: customColors.secondaryColor),
        ),
        collapsedWidget: Text(
          "Recycle bin",
          style: TextStyle(fontSize: 20, color: customColors.secondaryColor),
        ),
        bodyText: recycleBinNotes.isEmpty
            ? "No notes in recycle bin"
            : "Notes in recycle bin:",
        subBodyText: ListView.builder(
          itemCount: recycleBinNotes.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(
                recycleBinNotes[index].title,
                style: TextStyle(color: customColors.secondaryColor),
              ),
            );
          },
        ),
        backgroundColor: customColors.primaryColor,
        menuButton: IconButton(
          onPressed: () {
            Scaffold.of(context).openDrawer();
          },
          icon: const Icon(Icons.menu),
        ),
        notes: recycleBinNotes,
        onNoteDeleted: (int) {},
      ),
    );
  }
}
