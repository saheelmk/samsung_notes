import 'package:flutter/material.dart';
import 'package:samsung_note/themes/extension/theme.dart';
import 'package:samsung_note/screens/one_ui_nested_scroll.dart';
import 'package:samsung_note/widgets/appDrawers/drawer.dart';

class FolderWidget extends StatefulWidget {
  @override
  State<FolderWidget> createState() => _FolderWidgetState();
}

class _FolderWidgetState extends State<FolderWidget> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final customColors = Theme.of(context).extension<ThemeWidget>()!;

    return Scaffold(
      key: _scaffoldKey,
      drawer: AppDrawer(
        recycleBinNotes: [],
        settingsBackgroundColor: customColors.primaryColor,
        drawerColor: customColors.randomColor,
        textColor: customColors.secondaryColor,
        folderColor: customColors.buttonColor,
      ),
      body: OneUiNested(
        menuButton: IconButton(
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
          icon: const Icon(Icons.menu),
        ),
        onLongPressed: () {},
        expandedHeight: 300,
        toolbarHeight: 30,
        expandedWidget: Text(
          "Folders",
          style: TextStyle(fontSize: 30, color: customColors.secondaryColor),
        ),
        collapsedWidget: Text(
          "Folders",
          style: TextStyle(fontSize: 20, color: customColors.secondaryColor),
        ),
        bodyText: "No notes",
        subBodyText: Text(
          "Tap Add button to create a note",
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.normal, color: Colors.grey),
        ),
        backgroundColor: customColors.primaryColor,
        notes: [],
        onNoteDeleted: (int) {},
      ),
      floatingActionButton: Container(
        width: 55,
        height: 55,
        decoration: BoxDecoration(
          color: customColors.randomColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Colors.black38,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: IconButton(
          onPressed: () {},
          icon: const Icon(Icons.note_add_outlined),
          color: Colors.orange,
        ),
      ),
    );
  }
}
