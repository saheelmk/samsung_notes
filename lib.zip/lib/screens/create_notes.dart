import 'package:flutter/material.dart';
import 'package:samsung_note/widgets/note_model.dart';

class CreateNotes extends StatefulWidget {
  final Color backgroundColor;
  final Color appbarThings;
  CreateNotes(
      {super.key,
      required this.onNewNoteCreated,
      required this.backgroundColor,
      required this.appbarThings});
  final Function(NoteModel) onNewNoteCreated;

  @override
  State<CreateNotes> createState() => _CreateNotesState();
}

class _CreateNotesState extends State<CreateNotes> {
  final titleController = TextEditingController();
  final bodyController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: widget.backgroundColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context); // Navigate back
          },
          icon: const Icon(Icons.arrow_back_ios), // Back button icon
        ),
        title: TextField(
          controller: titleController,
          decoration: const InputDecoration(
            hintText: "Title",
            border: InputBorder.none,
          ),
          style: TextStyle(fontSize: 18, color: widget.appbarThings),
        ),
        actions: [
          CircleAvatar(
            radius: 20, // Circle size
            backgroundColor: widget.backgroundColor,
            child: IconButton(
              onPressed: () {
                // Add functionality for reading mode here
                print("Reading Mode");
              },
              icon: Icon(
                Icons.menu_book_outlined, // Book icon for reading mode
                color: widget.appbarThings, // Icon color
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              final note = NoteModel(
                  title: titleController.text, body: bodyController.text);

              widget.onNewNoteCreated(note);
              Navigator.pop(context);
            },
            child: Text(
              "Save",
              style: TextStyle(
                color: widget.appbarThings, // Save button color
                fontSize: 16,
              ),
            ),
          ),
          IconButton(
            onPressed: () {
              // Add more actions here
              print("More options");
            },
            icon: const Icon(Icons.more_vert), // Dots for additional actions
          ),
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: widget.backgroundColor,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(10),
              child: TextField(
                controller: bodyController,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                ),
                style: const TextStyle(fontSize: 20),
                maxLines: null, // Allows the TextField to grow to the next row
                keyboardType:
                    TextInputType.multiline, // Ensures multiline input
              ),
            ),
          ],
        ),
      ),
    );
  }
}
