import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:samsung_note/themes/extension/theme.dart';
import 'package:samsung_note/widgets/note_model.dart';

class NoteView extends HookWidget {
  const NoteView(
      {super.key,
      required this.note,
      required this.index,
      required this.onNoteDeleted});
  final NoteModel note;
  final int index;
  final Function(int) onNoteDeleted;

  @override
  Widget build(BuildContext context) {
    final customColors = Theme.of(context).extension<ThemeWidget>()!;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: customColors.primaryColor,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context); // Navigate back
          },
          icon: const Icon(Icons.arrow_back_ios), // Back button icon
        ),
        title: Text(
          note.title,
          style: const TextStyle(fontSize: 18),
        ),
        actions: [
          CircleAvatar(
            radius: 20, // Circle size
            backgroundColor: customColors.primaryColor,
            child: IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.edit_document, // edit Icon
                color: customColors.secondaryColor, // Icon color
              ),
            ),
          ),
          CircleAvatar(
            radius: 20, // Circle size
            backgroundColor: customColors.primaryColor,
            child: IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.search, // edit Icon
                color: customColors.secondaryColor, // Icon color
              ),
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              print("Selected: $value");
            },
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            color: customColors
                .randomColor, // Sets the popup menu's background color
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem(
                  child: Container(
                    width: 250, // Set desired width
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            "Full screen",
                            style:
                                TextStyle(color: customColors.secondaryColor),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            "Tags",
                            style:
                                TextStyle(color: customColors.secondaryColor),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            "Save as file",
                            style:
                                TextStyle(color: customColors.secondaryColor),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            "Print",
                            style:
                                TextStyle(color: customColors.secondaryColor),
                          ),
                        ),
                        const Divider(
                          color: Colors.grey,
                          thickness: 1,
                        ), // Add a divider
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            IconButton(
                              onPressed: () {},
                              icon: const Icon(Icons.star, size: 20),
                            ),
                            IconButton(
                              onPressed: () {},
                              icon: const Icon(Icons.share, size: 20),
                            ),
                            IconButton(
                              onPressed: () {
                                showModalBottomSheet(
                                  context: context,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(20),
                                    ),
                                  ),
                                  builder: (BuildContext context) {
                                    return Container(
                                      padding: EdgeInsets.all(16),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            "Move note to the Recycle bin?",
                                            style: TextStyle(
                                              fontSize: 15,
                                            ),
                                          ),
                                          SizedBox(height: 20),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              TextButton(
                                                onPressed: () {
                                                  Navigator.pop(
                                                      context); // Close the bottom sheet
                                                },
                                                child: Text(
                                                  "Cancel",
                                                  style: TextStyle(
                                                      color: customColors
                                                          .secondaryColor,
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                              Container(
                                                width: 1,
                                                height: 15,
                                                color: Colors.grey[400],
                                              ),
                                              TextButton(
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                  // Close the bottom sheet
                                                  onNoteDeleted(index);
                                                  Navigator.pop(context);
                                                },
                                                child: Text(
                                                  "Delete",
                                                  style: TextStyle(
                                                      color: customColors
                                                          .secondaryColor,
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                );
                              },
                              icon: const Icon(Icons.delete, size: 20),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ];
            },
            icon: const Icon(Icons.more_vert), // Icon to trigger the menu
          ),
        ],
      ),
      body: Container(
        color: customColors.primaryColor,
        child: ListView(
          children: [
            Divider(
              color: Colors.grey,
              thickness: 0.3,
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Text(
                note.body,
                style: const TextStyle(fontSize: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
