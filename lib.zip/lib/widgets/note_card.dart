import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:samsung_note/screens/note_view.dart';
import 'package:samsung_note/widgets/note_model.dart';

class NoteCardWidget extends HookWidget {
  const NoteCardWidget({
    super.key,
    required this.isIconvisible,
    required this.note,
    required this.index,
    required this.onNoteDeleted,
  });

  final NoteModel note;
  final int index;
  final Function(int) onNoteDeleted;
  final VoidCallback isIconvisible;

  @override
  Widget build(BuildContext context) {
    // State to track if the Icon should be shown

    return GestureDetector(
      onLongPress: () {
        isIconvisible();

        // Toggle the icon visibility on long press
      },
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext ctx) => NoteView(
              note: note,
              index: index,
              onNoteDeleted: onNoteDeleted,
            ),
          ),
        );
      },
      child: Stack(
        children: [
          Card(
            elevation: 3, // Adds shadow for a subtle effect
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    note.title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Center(
                    child: Text(
                      note.body,
                      style: const TextStyle(fontSize: 14),
                      maxLines: 2, // Limits to 2 lines
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
