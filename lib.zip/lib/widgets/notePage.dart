// import 'package:flutter/material.dart';

// final List<String> noteDescription = [];

// final List<String> noteHeading = [];

// TextEditingController noteHeadingController = TextEditingController();
// TextEditingController noteDescriptionController = TextEditingController();
// FocusNode textSecondFocusNode = FocusNode();

// int notesHeaderMaxLenght = 25;
// int notesDiscripMaxLines = 10;
// int? notesDescriptMaxLenght;
// String deleteNoteHeading = '';
// String deleteNoteDescript = '';
