class NoteModel {
  final String title;
  final String body;
  bool selected; // Added to track selection

  NoteModel({
    required this.title,
    required this.body,
    this.selected = false, // Default is unselected
  });
}
