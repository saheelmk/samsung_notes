import 'package:flutter/material.dart';

class BottomNavigationWidget extends StatelessWidget {
  const BottomNavigationWidget({
    super.key,
    required this.color,
    required this.bgColor,
    required this.index,
    required this.onNoteDeleted,
  });
  final Color color;
  final Color bgColor;
  final int index;
  final Function(int) onNoteDeleted;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildIconWithLabel(
              IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.drive_file_move_outlined,
                  size: 20,
                ),
              ),
              "Move",
              color),
          _buildIconWithLabel(
              IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.share,
                  size: 20,
                ),
              ),
              "Share",
              color),
          _buildIconWithLabel(
              IconButton(
                onPressed: () {
                  showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                            backgroundColor: bgColor,
                            title: Text(
                              "Move note to the Recycle bin?",
                              style: TextStyle(
                                  fontSize: 12,
                                  color: color,
                                  fontWeight: FontWeight.normal),
                            ),
                            content: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: Text(
                                    "Cancel",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: color,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () {
                                    onNoteDeleted(index);
                                    Navigator.pop(context);
                                  },
                                  child: Text(
                                    "Move to Recycle bin",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: color,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ],
                            ),
                          ));
                },
                icon: Icon(
                  Icons.delete,
                  size: 20,
                ),
              ),
              "Delete all",
              color),
          _buildIconWithLabel(
              IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.more_vert,
                  size: 20,
                ),
              ),
              "More",
              color),
        ],
      ),
    );
  }
}

Widget _buildIconWithLabel(IconButton icon, String label, Color color) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      icon,
      Text(
        label,
        style: TextStyle(fontSize: 10, color: color),
      ),
    ],
  );
}
