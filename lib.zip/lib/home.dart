import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:samsung_note/screens/create_notes.dart';
import 'package:samsung_note/themes/extension/theme.dart';
import 'package:samsung_note/widgets/bottomNavigation.dart';
import 'package:samsung_note/widgets/checkBox.dart';
import 'package:samsung_note/widgets/appDrawers/drawer.dart';
import 'package:samsung_note/screens/one_ui_nested_scroll.dart';
import 'package:samsung_note/widgets/note_model.dart';

class SamsungNoteHomePage extends HookWidget {
  const SamsungNoteHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final isLongpressed = useState(true);
    final notes = useState<List<NoteModel>>([]);
    final recycleBinNotes =
        useState<List<NoteModel>>([]); // New recycle bin list
    final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

    final customColors = Theme.of(context).extension<ThemeWidget>()!;

    void onNewNoteCreated(NoteModel note) {
      notes.value = [...notes.value, note];
    }

    void onNoteMovedToRecycleBin(int index) {
      recycleBinNotes.value = [...recycleBinNotes.value, notes.value[index]];
      notes.value = List.from(notes.value)..removeAt(index);
    }

    return Scaffold(
      key: scaffoldKey,
      drawer: AppDrawer(
        recycleBinNotes: recycleBinNotes.value,
        settingsBackgroundColor: customColors.primaryColor,
        drawerColor: customColors.randomColor,
        textColor: customColors.secondaryColor,
        folderColor: customColors.buttonColor,
      ),
      body: OneUiNested(
        menuButton: isLongpressed.value
            ? IconButton(
                onPressed: () {
                  scaffoldKey.currentState?.openDrawer();
                },
                icon: const Icon(Icons.menu),
              )
            : const Padding(
                padding: EdgeInsets.only(left: 10),
                child: CheckBoxWidget(),
              ),
        onLongPressed: () {
          isLongpressed.value = !isLongpressed.value;
        },
        expandedHeight: 400,
        toolbarHeight: 40,
        expandedWidget: isLongpressed.value
            ? Text(
                "All notes",
                style:
                    TextStyle(fontSize: 30, color: customColors.secondaryColor),
              )
            : Text(
                "${notes.value.length} Selected",
                style:
                    TextStyle(fontSize: 30, color: customColors.secondaryColor),
              ),
        collapsedWidget: Text(
          "All notes",
          style: TextStyle(
              fontSize: 20,
              color: customColors.secondaryColor,
              letterSpacing: 0),
        ),
        bodyText: notes.value.isEmpty ? "No notes" : "",
        subBodyText: const Text(
          "Tap Add button to create a note",
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.normal, color: Colors.grey),
        ),
        backgroundColor: customColors.primaryColor,
        notes: notes.value,
        onNoteDeleted: onNoteMovedToRecycleBin, // Updated callback
      ),
      floatingActionButton: isLongpressed.value
          ? Container(
              width: 55,
              height: 55,
              decoration: BoxDecoration(
                color: customColors.randomColor,
                shape: BoxShape.circle,
                boxShadow: [
                  const BoxShadow(
                    color: Colors.black38,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext ctx) => CreateNotes(
                        appbarThings: customColors.secondaryColor,
                        backgroundColor: customColors.primaryColor,
                        onNewNoteCreated: onNewNoteCreated,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.note_add_outlined),
                color: Colors.orange,
              ),
            )
          : BottomNavigationWidget(
              onNoteDeleted: onNoteMovedToRecycleBin, // Updated callback
              index: 0,
              bgColor: customColors.primaryColor,
              color: customColors.secondaryColor,
            ),
    );
  }
}
